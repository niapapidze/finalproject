from django.shortcuts import render, redirect
from .forms import ReviewForm
from .models import Review
def submit_review(request):
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            Review.objects.create(
                username=form.cleaned_data['username'],
                email=form.cleaned_data['email'],
                rating=form.cleaned_data['rating'],
                comment=form.cleaned_data['comment']
            )
            return redirect('thank_you')
    else:
        form = ReviewForm()
    return render(request, 'submit_review.html', {'form': form})







from django.shortcuts import render
from .models import Review

def product_reviews(request):
    reviews = Review.objects.all()
    return render(request, 'product_reviews.html', {'reviews': reviews})
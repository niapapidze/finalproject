from flask import render_template, redirect, Flask, session, flash
from flask_login import login_user, logout_user, login_required, current_user
from os import path

from models import Product, Comment, User

from forms import RegisterForm, ProductForm, LoginForm

app = Flask(__name__)
profiles = []


@app.route("/home")
def home():
    products = Product.query.all()
    return render_template("home.html", products=products, role="Admin")


@app.route("/register", methods=["GET", "POST"])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        new_user = User(username=form.username.data, password=form.password.data)
        new_user.create()
        return redirect("/")
    return render_template("register.html", form=form)


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        flash("You're already logged in")
        return redirect("/")

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            flash("You've logged in!")
            return redirect("/")
    return render_template("login.html", form=form)


@app.route("/create_product", methods=["GET", "POST"])
@login_required
def create_product():
    form = ProductForm()
    if form.validate_on_submit():
        new_product = Product(name=form.name.data, price=form.price.data)

        image = form.img.data
        directory = path.join(app.root_path, "static", "images", image.filename)
        image.save(directory)

        new_product.img = image.filename
        new_product.create()
        return redirect("/")
    return render_template("create_product.html", form=form)


@app.route("/edit_product/<int:product_id>", methods=["GET", "POST"])
@login_required
def edit_product(product_id):
    product = Product.query.get(product_id)
    form = ProductForm(name=product.name, price=product.price)
    if form.validate_on_submit():
        product.name = form.name.data
        product.price = form.price.data
        product.save()
        return redirect("/")
    return render_template("create_product.html", form=form)


@app.route("/delete_product/<int:product_id>")
@login_required
def delete_product(product_id):
    product = Product.query.get(product_id)
    product.delete()
    return redirect("/")


@app.route("/product/<int:product_id>")
def product(product_id):
    product = Product.query.get(product_id)
    comments = Comment.query.filter_by(product_id=product_id).all()
    return render_template("product_details.html", product=product, comments=comments)
@app.route("/")
def index():
    return render_template("index.html")
@app.route("/about")
def index():
    return render_template("about.html")



if __name__ == '__main__':
    app.run(debug=True)

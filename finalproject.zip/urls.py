

urlpatterns = [
    path('submit-review/', submit_review, name='submit_review'),
]

from .views import product_reviews

urlpatterns = [
    path('submit-review/', submit_review, name='submit_review'),
    path('reviews/', product_reviews, name='product_reviews'),
]
